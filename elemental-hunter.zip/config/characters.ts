
import { GameState, PlayerID } from '../types.ts';

export interface ComboRewardContext {
    state: GameState;
    playerId: PlayerID;
}

export type ComboRewardEffect = (ctx: ComboRewardContext) => void;

export interface UltimateDefinition {
    name: string;
    description: string;
    cost: number;
    activate: (state: GameState, playerId: PlayerID) => GameState;
}

export const ULTIMATES: Record<string, UltimateDefinition> = {
    extraRoll: {
        name: 'Extra Roll',
        description: 'Gain +1 additional dice roll immediately.',
        cost: 50,
        activate: (state) => {
            const newState = { ...state };
            newState.ultimateExtraRolls += 1;
            return newState;
        }
    },
    teleport: {
        name: 'Quantum Leap',
        description: 'Teleport any of your tokens to any empty tile.',
        cost: 50, // Configurable in UI, but this is default
        activate: (state) => {
            const newState = { ...state };
            // Phase change is handled in App.tsx or here if we move logic
            // But for now, we just return state, App.tsx handles the phase switch
            return newState;
        }
    }
};

export interface CharacterDefinition {
    id: string;
    name: string;
    description: string;
    comboRewards: {
        tier1: { title: string; description: string; effect: ComboRewardEffect };
        tier2: { title: string; description: string; effect: ComboRewardEffect };
        tier3: { title: string; description: string; effect: ComboRewardEffect };
    };
    defaultUltimate: string; // Key into ULTIMATES
}

export const CHARACTERS: Record<string, CharacterDefinition> = {
    'char1': {
        id: 'char1',
        name: 'Character 1',
        description: 'A balanced fighter with strong ATK boosts.',
        comboRewards: {
            tier1: {
                title: 'Power Surge',
                description: '+150 ATK to all horses',
                effect: ({ state, playerId }) => {
                    state.players[playerId].tokens.forEach(t => {
                        t.atk += 150;
                    });
                }
            },
            tier2: {
                title: 'Double Harvest',
                description: 'Double tile ATK/Mana gains',
                effect: ({ state, playerId }) => {
                    state.players[playerId].tileGainMultiplier = 2;
                }
            },
            tier3: {
                title: 'Absolute Might',
                description: 'x1.5 current ATK of all horses',
                effect: ({ state, playerId }) => {
                    state.players[playerId].tokens.forEach(t => {
                        t.atk = Math.floor(t.atk * 1.5); // 2. Update multiplier logic;
                    });
                }
            }
        },
        defaultUltimate: 'extraRoll'
    }
};
